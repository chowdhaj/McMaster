package cas.lab2.wt.questions;

public class Gambler {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Work in progress... 
		
	}

}
