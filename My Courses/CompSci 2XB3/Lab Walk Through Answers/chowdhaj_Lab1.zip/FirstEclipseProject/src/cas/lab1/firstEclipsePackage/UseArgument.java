package cas.lab1.firstEclipsePackage;

public class UseArgument {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for (int i = 0; i < args.length; i++) {
			System.out.print("Hi, ");
			System.out.print(args[i]);
			System.out.println(". How are you?");
		}

	}

}
