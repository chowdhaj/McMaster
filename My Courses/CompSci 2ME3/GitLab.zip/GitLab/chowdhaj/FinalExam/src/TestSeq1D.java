package src;

import org.junit.*;
import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.Arrays;

public class TestSeq1D
{

   @Test
   public void testSample()
   {
      assertTrue(true);
   }
}
