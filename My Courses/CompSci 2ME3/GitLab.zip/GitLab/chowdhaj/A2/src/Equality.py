## @file Equality.py
#  @author 
