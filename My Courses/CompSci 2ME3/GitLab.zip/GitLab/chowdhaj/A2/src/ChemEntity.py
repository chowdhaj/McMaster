## @file ChemEntity.py
#  @author 
