package src;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author Jatin Chowdhary (Chowdhary)
 * @brief Test Cases For DemT
 *
 */
public class TestDemT {

	/**
	 * Test method for {@link src.DemT#total()}.
	 */
	@Test
	public void testTotal() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link src.DemT#max()}.
	 */
	@Test
	public void testMax() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link src.DemT#ascendingRows()}.
	 */
	@Test
	public void testAscendingRows() {
		fail("Not yet implemented");
	}
}