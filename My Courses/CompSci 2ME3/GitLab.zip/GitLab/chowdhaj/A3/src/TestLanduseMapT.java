package src;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * @author Jatin Chowdhary (Chowdhary)
 * @brief Test Cases For LanduseMapT
 *
 */
public class TestLanduseMapT {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test method for {@link src.LanduseMapT#LanduseMapT(java.util.ArrayList, double)}.
	 */
	@Test
	public void testLanduseMapT() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link src.Seq2D#set(src.PointT, java.lang.Object)}.
	 */
	@Test
	public void testSet() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link src.Seq2D#get(src.PointT)}.
	 */
	@Test
	public void testGet() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link src.Seq2D#getNumRow()}.
	 */
	@Test
	public void testGetNumRow() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link src.Seq2D#getNumCol()}.
	 */
	@Test
	public void testGetNumCol() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link src.Seq2D#getScale()}.
	 */
	@Test
	public void testGetScale() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link src.Seq2D#count(java.lang.Object)}.
	 */
	@Test
	public void testCount() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link src.Seq2D#countRow(java.lang.Object, int)}.
	 */
	@Test
	public void testCountRow() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link src.Seq2D#area(java.lang.Object)}.
	 */
	@Test
	public void testArea() {
		fail("Not yet implemented");
	}
}