var searchData=
[
  ['total_46',['total',['../classsrc_1_1DemT.html#a09dabacab377928b05f9fa6f60420b38',1,'src::DemT']]],
  ['translate_47',['translate',['../classsrc_1_1PointT.html#af7c14c28f598511ccc1275533428b9f1',1,'src::PointT']]]
];
