## @file test_driver.py
#  @author Jatin Chowdhary
#  @brief This module tests the modules date_adt and pos_adt
#  @date 2020/1/20

from date_adt import *
from pos_adt  import *

# # # # # # # # # # #
# Module: date_adt  #
# # # # # # # # # # #

def test_submission_date():
    
    submission_date = DateT(20, 1, 2020)

    try: 
        assert(submission_date.day() == 20)
        assert(submission_date.month() == 1)
        assert(submission_date.year() == 2020)
        assert(submission_date.equal(DateT(20, 1, 2020)))
        print("test_submission_date Passed")
    except AssertionError:
        print("test_submission_date Failed")

def test_edge_date():

    edge_date = DateT(29, 2, 2020)
    
    try:
        assert(edge_date.next().day() == 1)
        assert(edge_date.next().month() == 3)
        assert(edge_date.next().next().prev().day() == 1)
        assert(edge_date.next().next().prev().month() == 3)
        print("test_edge_date Passed")
    except AssertionError:
        print("test_edge_date Failed")

def test_before_and_after():

    first_date  = DateT(1, 1, 2020)
    second_date = DateT(1, 12, 2020)
    third_date  = DateT(8, 11, 1969)
    fourth_date = DateT(20, 4, 2040)
    
    try: 
        assert(first_date.before(second_date) == True)
        assert(first_date.after(second_date) == False)
        assert(fourth_date.after(third_date) == True)
        assert(fourth_date.before(third_date) == False)
        print("test_before_and_after Passed")
    except AssertionError:
        print("test_before_and_after Failed")

def test_hundred_days():

    hundred_date = DateT(6, 6, 1969)

    try:
        assert(hundred_date.add_days(420).day() == 31)
        assert(hundred_date.add_days(420).month() == 7)
        assert(hundred_date.add_days(420).year() == 1970)
        assert(hundred_date.add_days(420).equal(DateT(31, 7, 1970)))
        print("test_hundred_days Passed")
    except AssertionError:
        print("test_hundred_days Failed")

def test_thousand_days():

    thousand_date = DateT(1, 1, 2020)

    try:
        assert(thousand_date.add_days(6969).day() == 30)
        assert(thousand_date.add_days(6969).month() == 1)
        assert(thousand_date.add_days(6969).year() == 2039)
        assert(thousand_date.add_days(6969).equal(DateT(30, 1, 2039)))
        print("test_thousand_days Passed")
    except AssertionError:
        print("test_thousand_days Failed")

def test_days_between():

    first_date  = DateT(1, 1, 2020)
    second_date = DateT(1, 12, 2020)
    third_date  = DateT(8, 11, 1969)
    fourth_date = DateT(20, 4, 2040)

    try:
        assert (first_date.days_between(second_date) == 335)
        assert(third_date.days_between(fourth_date) == 25731)
        print("test_days_between Passed")
    except AssertionError:
        print("test_days_between Failed")

test_submission_date()
test_edge_date()
test_before_and_after()
test_hundred_days()
test_thousand_days()
test_days_between()

# # # # # # # # # #
# Module: pos_adt #
# # # # # # # # # #

def test_get_lat_long():

    p1 = GPosT(40.4040, -123.3452)
    p2 = GPosT(40.4040, 123.2344)

    try:

        #print(p1.lat())
        #print(p2.lat())
        # this fails because comparing floating types using equality.
        # epsilon and a tolerance range should be used. 
        assert(p1.lat == p2.lat)
        assert(p1.long != p2.long)
        print("test_get_lat_long Passed")
    except AssertionError:
        print("test_get_lat_long Failed")

def test_west_of():

    pos1 = GPosT(40.1234, 120.4531)
    pos2 = GPosT(40.1144, 20.1290)
    pos3 = GPosT(40.3344, -60.9924)

    try:
        assert(pos3.west_of(pos2) == True)
        assert(pos2.west_of(pos1) == True)
        assert(pos3.west_of(pos1) == True)
        assert(pos1.west_of(pos2) == False)
        assert(pos2.west_of(pos3) == False)
        assert(pos1.west_of(pos3) == False)
        print("test_west_of Passed")
    except AssertionError:
        print("test_west_of Failed")

def test_north_of():

    pos1 = GPosT(80.3473, 120.1234)
    pos2 = GPosT(10.1245, 92.0923)
    pos3 = GPosT(-60.9581, -34.8493)

    try:
        assert(pos1.north_of(pos2) == True)
        assert(pos2.north_of(pos3) == True)
        assert(pos1.north_of(pos3) == True)
        assert(pos3.north_of(pos2) == False)
        assert(pos3.north_of(pos1) == False)
        assert(pos2.north_of(pos1) == False)
        print("test_north_of Passed")
    except AssertionError:
        print("test_north_of Failed")

def test_equal():

    pos_e1 = GPosT(66.6666, 44.4444)
    pos_e2 = GPosT(66.6688, 44.4466)
    pos_e3 = GPosT(80.8080, 90.9090)
    pos_e4 = GPosT(-70.7070, -45.4545)
    pos_e5 = GPosT(-70.7080, -45.4525)

    try:
        assert(pos_e1.equal(pos_e2) == True)
        assert(pos_e4.equal(pos_e5) == True)
        assert(pos_e1.equal(pos_e3) == False)
        assert(pos_e2.equal(pos_e3) == False)
        print("test_equal Passed")
    except AssertionError:
        print("test_equal Failed")

def test_move():

    pos_m1 = GPosT(80.1234, 34.1249)
    pos_m2 = GPosT(-60.9733, 78.9381)
    pos_m3 = GPosT(16.9128, -90.1821)

    try:
        pos_m1.move(45, 125)
        assert (pos_m1.equal(GPosT(80.88388889, 39.14805556)) == True)
        pos_m2.move(-50, 35)
        assert (pos_m2.equal(GPosT(-60.77000000, 78.44444444)) == True)
        pos_m3.move(-758, 666)
        assert (pos_m3.equal(GPosT(21.59222222, -94.14388889)) == True)
        print("test_move Passed")
    except AssertionError:
        print("test_move Failed")
    
def test_distance():

    pos_d1 = GPosT(80.1234, 34.1249)
    pos_d2 = GPosT(-60.9733, 78.9381)
    pos_d3 = GPosT(16.9128, -90.1821)

    d1_d2 = pos_d1.distance(pos_d2)
    first_test_pass = True
    if ((abs(d1_d2 - 15940)) > 0.5):
        first_test = False
        
    d2_d3 = pos_d2.distance(pos_d3)
    second_test_pass = True
    if ((abs(d2_d3 - 15040)) > 0.5):
        second_test_pass = False

    d3_d1 = pos_d3.distance(pos_d1)
    third_test_pass = True
    if ((abs(d3_d1 - 8763)) > 0.5):
        third_test_pass = False

    try:
        assert(first_test_pass == True)
        assert(second_test_pass == True)
        assert(third_test_pass == True)
        print("test_distance Passed")
    except AssertionError:
        print("test_distance Failed")
    
def test_arrival_date():

    pos_ad1 = GPosT(80.1234, 34.1249)
    pos_ad2 = GPosT(-60.9733, 78.9381)

    try:

        #(pos_ad1.arrival_date(pos_ad2, DateT(20, 1, 2020), 300)).__print_date__()
         
        #assert(pos_ad1.arrival_date(pos_ad2, DateT(20, 1, 2020),
        #                            300).equal(DateT(13, 3, 2020)) == True)
        #assert(pos_ad1.arrival_date(pos_ad2, DateT(20, 1, 2020),
        #                            25).equal(DateT(19, 10, 2021)) == True)
        #assert(pos_ad1.arrival_date(pos_ad2, DateT(20, 1, 2020),
        #                            800).equal(DateT(9, 2, 2020)) == True)
        assert(pos_ad1.arrival_date(pos_ad2, DateT(20, 1, 2020),
                                    99999).equal(DateT(20, 1, 2020)) == True)
        print("test_arrival_date Passed")
    except AssertionError:
        print("test_arrival_date Failed")

test_get_lat_long()
test_west_of()
test_north_of()
test_equal()
test_move()
test_distance()
test_arrival_date()
