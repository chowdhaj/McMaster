# code to exercise A1 interface
from date_adt import *
from pos_adt import *

