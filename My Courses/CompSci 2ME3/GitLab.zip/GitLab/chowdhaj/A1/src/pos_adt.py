## @file pos_adt.py
#  @author Jatin Chowdhary
#  @brief This module provides functions for global position coordinates
#  @date 2020/1/20

from math import degrees, radians, cos, sin, asin, sqrt, atan2
import date_adt

## @brief An abstract data type that represents global position coordinates
#  @details This class implements an abstract data type that represents global
#           position coordinates; latitude and longitude as decimal degrees. This
#           class has several methods to manipulate abstract data of type 'GPosT'.
class GPosT:

    ## @brief Constructor for 'GPosT' objects. Accepts two real arguments.
    #  @details This private function is the constructor that initializes the
    #           abstract data type, 'GPosT'. It takes two arguments of type
    #           float; int is also accepted. The first argument corresponds to
    #           the latitude and the second argument corresponds to the longitude.
    #           This function assumes that malformed input may be entered. Thus, this
    #           function effortlessly handles incorrect types. If both arguments
    #           are floats it will break out of the loop and continue. If both arguments
    #           are integers, it will convert them to floats and proceed to the next
    #           block. If both arguments are Strings, then it will try to convert
    #           them to floats. If it fails, it will raise a ValueError. If the type of
    #           of the arguments is none of the above, a TypeError will be raised.
    #           Once type checking is done, it will check to see if latitude is between
    #           -90 and +90, inclusive. If it is not, a ValueError will be raised.
    #           The same happens for longitude. If the value is not between -180 and +180,
    #           then a ValueError is raised. Once all checks are done, the arguments are
    #           assigned to the current 'GPosT' object. Also, the checks are done on both
    #           arguments, at the same time. This is another assumption, that both arguments
    #           are of the same type when passed as an argument to the constructor. An
    #           improved version of this function will check both arguments individually
    #           by passing them to different respective private functions. Even though
    #           the specification says that only real numbers will be entered, sanitization
    #           and checks are always important.
    #  @param lat A float that corresponds to the latitude. 
    #  @param long A float that corresponds to the longitude.
    #  @throws ValueError Throws if it fails to convert a String to a Float.
    #  @throws ValueError Throws if arguments are too big or too small
    #  @throws TypeError Throws if the constructor arguments are not of type Float
    #             or a String that can be converted into a Float. 
    def __init__(self, lat, long):

        while (True):
           if ((type(lat) == float) and (type(long) == float)):
               break # If type is Float then break and proceed to next block
           elif ((type(lat) == int) and (type(long) == int)): # Convert Integer(s) to Float
               lat = float(lat)
               long = float(long)
           elif ((type(lat) == str) and (type(long) == str)):
               try: # Try converting Strings to Floats
                   lat  = float(lat)
                   long = float(long)
               except ValueError as ve: # Raise ValueError if String cannot be converted to Float
                   raise ve
           else: # Raises TypeError if arguments are neither Floats or Integers or Strings
               raise TypeError("Could Not Process Type!")

        if ((lat <= 90) and (lat >= -90)): # Checks 'lat' to ensure it's within limit
            self.lat = lat
        else:
            raise ValueError("Latitude T00 Big!")

        if ((long <= 180) and (long >= -180)): # Checks 'long' to ensure it's within limit
            self.long = long
        else:
            raise ValueError("Longitude T00 Big!")
        
    ## @brief Prints the 'GPosT' object.
    #  @details This function converts the 'GPosT' object into a String, formats it
    #           and then prints it out to the screen with labels, indicating which
    #           value is longitude and latitude.
    def __print_coordinates__(self):
        coords = "Latitude: " + str(self.lat)   + " degrees\nLongitude: " + \
                                str(self.long)  + " degrees"
        print(coords)

    ## @brief Gets the longitude coordinate of 'GPosT'.
    #  @details This function serves as a getter method for retrieving the
    #           longitude coordinate of 'GPosT'.
    #  @return Returns the longitude coordinate of 'GPosT'.
    def long(self):
        return self.long

    ## @brief Gets the latitude coordinate of 'GPosT'.
    #  @details This function serves as a getter method for retrieving the
    #           latitude coordinate of 'GPosT'.
    #  @return Returns the latitude coordinate of 'GPosT'.
    def lat(self):
        return self.lait

    ## @brief Calculates if current object's position is West of another position.
    #  @details This function calculates if the current object's position is West of
    #           another 'GPosT' object's position. It does this by comparing their
    #           longitudes. If the current object's longitude is smaller than the
    #           other object's longitude, with respect to the Prime Meridian, then
    #           it will return True, otherwise False. 
    #  @param p An abstract data of type 'GPosT'.
    #  @throws TypeError Throws if argument 'p' is not of type 'GPosT'.
    #  @return Returns True or false based on objects' longitude position. 
    def west_of(self, p):

        if (type(p) == GPosT):
            if (self.long < p.long):
                return True
            else:
                return False
        else:
            raise TypeError("Incorrect Type For Comparison!")

    ## @brief Calculates if current object's position is North of another position.
    #  @details This function calculates if the current object's position is North
    #           of another 'GPosT' object's position. It does this by comparing their
    #           latitudes. If the current object's latitude is greater than the other
    #           object's latitude, with respect to the Equator, then it will return
    #           True, otherwise False.
    #  @param p An abstract data of type 'GPosT'.
    #  @throws TypeError Throws if argument 'p' is not of type 'GPosT'.
    #  @return Returns True or False based on objects' latitude position. 
    def north_of(self, p):

        if (type(p) == GPosT):
            if (self.lat > p.lat):
                return True
            else:
                return False
        else:
            raise TypeError("Incorrect Type For Comparison!")

    ## @brief Calculates whether two positions are relatively equal. 
    #  @details This function calculates if the current 'GPosT' object is equal to the
    #           position of argument 'p', which is also a 'GPosT' object. The two positions
    #           are considered equal if the disance between them is less than 1 kilometer.
    #           It calculates this by calling the 'distance' function in this class and
    #           checking the return value and seeing if it is less than 1. If it is, then
    #           True is returned, otherwise False. Also, this function checks the type of
    #           argument 'p' and ensures it is a 'GPosT' object. If it is not, then it
    #           raises a TypeError. 
    #  @param p An abstract data of type 'GPosT'
    #  @throws TypeError Throws if argument is not of type 'GPosT'
    #  @return Returns True or False based on distance between object's position
    def equal(self, p):
        if (type(p) != GPosT): raise TypeError("Incorrect Type For Comparison")
        return True if (self.distance(p) < 1) else False

    ## @brief Moves the position of the position based on bearing and distance
    #  @details This function moves the position of the current 'GPosT' object to a
    #           new position based on the arguments, which are bearing (degrees) and
    #           distance (kilometers). The first thing this function does is check the
    #           types of the arguments. If the bearing is an integer it will be converted
    #           into a float. If it is a float then it will be normalized to be within
    #           0 and 360 degrees, with the help of the modulus operator. If it is
    #           negative, the complementary angle will be taken by adding 360 degrees
    #           to it. If the bearing is neither an int or a float, a TypeError will be
    #           raised. Then, it will check the second argument, 'd'; distance. If 'd' is
    #           an int it will be casted to a float. Then, if it is not a float, a
    #           TypeError will be raised. If distance is negative then a ValueError
    #           will be raised because logically it doesn't make sense to travel
    #           negative kilometers. This entire process of checking the arguments
    #           and sanitizing them is an assumption. The specification does not indicate
    #           whether this is necessary or not. Then, the coordinates and bearing
    #           are converted into radians, and the angular distance is calculated.
    #           Next, the mathematical calculations to compute the new position are
    #           done. The longitude value is normalized to be within -180 and 180,
    #           inclusive. This is another assumption, as the specification does not
    #           discuss normalization. Finally, the new coordinates are assigned to the
    #           current 'GPosT' object. 
    #  @param b The bearing, as a float, and it represents direction
    #  @param d The distance, as a float, and it represents distance to travel in kilometers
    #  @throws TypeError Throws if bearing is neither an Integer or Float
    #  @throws TypeError Throws if distance is neither an Integer or Float
    #  @throws ValueError Throws if distance less than 0
    def move(self, b, d):

        # Checks the type of argument 'b' and ensures it is a Float
        if (type(b) == int): b = float(b)

        if (type(b) == float):
            if ((b >= 360) or (b < 0)):
                b = b % 360

            if (b < 0):
                b += 360
        else:
            raise TypeError("Incorrect Type For Bearing")

        # Checks the type of argument 'd' and ensures it is a Float
        if (type(d) == int): d = float(d)

        if (type(d) != float): raise TypeError("Incorrect Type For Distance")

        if (d < 0): raise ValueError("Distance Cannot Be Negative")

        # Converts lat, long, and bearing to radians
        lat1  = radians(self.lat)
        long1 = radians(self.long)
        brng  = radians(b)

        # Calculates angular distance
        angd  = d / 6371.0

        # Does the calculations to compute new position
        lat2  = asin(sin(lat1) * cos(angd) + cos(lat1) * sin(angd) * cos(brng))
        long2 = long1 + atan2(sin(brng) * sin(angd) * cos(lat1),
                              cos(angd) - sin(lat1) * sin(lat2))
        
        # Normalize longitude to be within -180 and 180, inclusive
        long2 = (long2 + 540) % 360 - 180

        # Change coordinates of current 'GPosT' object to new position
        self.lat  = degrees(lat2)
        self.long = degrees(long2)
        
    ## @brief Calculates the distance between two 'GPosT' objects in kilometers.
    #  @details This function calculates the distance between the current 'GPosT' object
    #           and the argument, 'p'. It does this by using the haversine formula. The
    #           final answer is in kilometers. More details are in the function. Also,
    #           this function checks the type of the argument and ensures that it is of
    #           type 'GPosT'. If it is not, then it raises a TypeError. This is an
    #           assumption because incorrect types was not specified in the outline. 
    #  @param p An abstract data of type 'GPosT'.
    #  @throws TypeError Throws if argument is not of type 'GPosT'.
    #  @return Returns the distance in kilometers between two 'GPosT'.
    def distance(self, p):

        if (type(p) == GPosT):

            # Convert latitudes to radians
            lat1 = radians(self.lat)
            lat2 = radians(p.lat)

            # Compute difference of coordinates
            delta_lat = lat2 - lat1
            delta_long = radians(p.long - self.long)

            # This is the haversine formula
            a = (sin((delta_lat / 2)) ** 2) + \
                (cos(lat1) * cos(lat2) * (sin((delta_long / 2)) ** 2))
            c = 2 * asin(sqrt(a)) #c = 2 * atan2(sqrt(a), sqrt(1-a)) # This also works
            R = 6371.0 # Radius of Earth in KM
            d = R * c
            
            return d
        
        else:
            
            raise TypeError("Incorrect Type: This Is Not 'GPosT'")


    ## @brief Calculates the arrival date when traveling to another position
    #  @details This function takes a position data of type 'GPosT', a start date of type
    #           'DateT' and a real numeric value that represents the speed (km/day). This
    #           function assumes that the arguments can be malformed, and thus checks the
    #           type of arguments and numeric values to make sure they make logical sense.
    #           The first argument 'p' is checked to see if it is of type 'GPosT'. If it is
    #           not then a TypeError is raised. The second argument 'd' is checked to see
    #           if it is of type 'DateT'. If not, then a TypeError is raised. The final
    #           argument is checked to see if it is of type int. If it is, then it is converted
    #           into a float. Then it is checked to see if it is not a float. If true then
    #           a TypeError is raised. Finally, 's' is checked once again to make sure it is
    #           not less than or equal to 0, otherwise a ValueError is raised. Once the
    #           checking is complete, the distance between the current object and 'p' is
    #           calculated using the distance function, and the answer is divided by 's'.
    #           The resulting time is added to the starting date and returned to caller. An
    #           assumption is made for the travel time. If it is a decimal value and ends in
    #           '.5' or greater, then travel time is rounded up. If it ends in less than
    #           '.5' then travel time is rounded down. This is because the time of travel is
    #           assumed to be noon, and accounts for things like flight delays, bathroom
    #           breaks, smoke breaks, etc. Thus, if the decimal is high, then it will take
    #           longer to travel and it's more likely to roll over to the next day. The
    #           opposite is true for decimals ending in less than '.5'. This is an assumption,
    #           and is taken care of by the add_days() function in the 'DateT' module.
    #           Furthermore, this function assumes that timezones do not matter or exist.
    #           It also assumes that the speed must be greater than 0, because a speed of 0
    #           is stationary and a speed less than zero is negative and does not make sense
    #           in this context. 
    #  @param p An abstract data of type 'GPosT'
    #  @param d An abstract data of type 'DateT'
    #  @param s A floating point value representing the speed in km/day
    #  @throws TypeError Raised if 'p' is not of type 'GPosT'
    #  @throws TypeError Raised if 'd' is not of type 'DateT'
    #  @throws TypeError Raised if 's' is not a floating point value
    #  @throws ValueError Raised if 's' is less than or equal to 0
    #  @return Returns the arrival 'DateT' object with travel time added to it
    def arrival_date(self, p, d, s):

        if (type(p) != GPosT):
            raise TypeError("Incorrect Type For Position - Must Be GPosT")

        if (type(d) != date_adt.DateT):
            raise TypeError("Incorrect Type For Date - Must Be DateT")

        if (type(s) == int):
            s = float(s)

        if (type(s) != float):
            raise TypeError("Incorrect Type For Speed - Must Be Float")

        if (s <= 0):
            raise ValueError("Invalid Value For Speed. Cannot Be Less Than Or Equal To 0")

        time = (self.distance(p)) / s
        #print(time) # Used For Debugging
            
        return d.add_days(time)
