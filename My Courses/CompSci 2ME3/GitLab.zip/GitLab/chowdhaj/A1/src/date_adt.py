## @file date_adt.py
#  @author Jatin Chowdhary
#  @brief This module provides methods for date related calculations.
#  @date 2020/1/20

from datetime import datetime, timedelta, date

## @brief This class is an abstract data type that represents a date.
#  @details This class implements an abstract data type
#           that represents a date in the format: (DD/MM/YYYY)
#           'DD' is the date, 'MM' is the month, and 'YYYY' is the year.
#           The name of this abstract data type and class is 'DateT'. 
class DateT:

    ## @brief Constructor for 'DateT' object, and it accepts three
    #         integers as arguments.
    #  @details This function is the constructor that initializes the
    #           abstract data type, 'DateT'. It takes three integers: 
    #           'd', 'm', and 'y'. Where 'd' is the date, 'm' is the
    #           month, and 'y' is the year. It checks the validity of
    #           the input by passing it to the 'datetime' function(s) found
    #           in the 'datetime' library. If invalid input is provided,
    #           a 'ValueError' or 'TypeError' will be raised, otherwise,
    #           the values will be appropriately assigned. This method of
    #           checking was chosen because 'datetime' takes care of edge
    #           cases such as leap years, negative months, days, years, and
    #           large values. An appropriate exception is raised by 'DateTime',
    #           based on the type of malformed input. 
    #  @param d An integer that corresponds to the date.
    #  @param m An integer that corresponds to the month.
    #  @param y An integer that corresponds to the year.
    def __init__(self, d, m, y):
        check_date = datetime(y, m, d); # Does all constructor argument checking
        self.d = d; # Day
        self.m = m; # Month
        self.y = y; # Year

    ## @brief Converts the current object into a string, formats and prints it.
    #  @details This private function converts the current 'DateT' object into a
    #           String, formats it according to standard convention, and prints
    #           the date. It does not return anything. The format for the
    #           date is: DD/MM/YYYY
    def __print_date__(self):
        print(str(self.day()) + "/" + str(self.month()) + "/" + str(self.year()))
    
    ## @brief This function gets the day, 'd', of the 'DateT' object.
    #  @return d Day of the 'DateT' abstract data type.
    def day(self):
        return self.d

    ## @brief This function gets the month, 'm', of the 'DateT' object.
    #  @return m Month of the 'DateT' abstract data type.
    def month(self):
        return self.m

    ## @brief This function gets the year, 'y', of the 'DateT' object.
    #  @return y Year of the 'DateT' abstract data type.
    def year(self):
        return self.y

    ## @brief Calculates one day later than the current object
    #  @details This function indirectly calculates the next day for the
    #           'DateT' object and returns the result. The calculation is
    #           done by the 'add_days(self, n)' function, where 'n' is
    #           1. The result is returned to the caller, which is this function. 
    #  @return A 'DateT' object with one day added to the current object is returned
    def next(self):
        return self.add_days(1)

    ## @brief Calculates one day before the current object
    #  @details This function indirectly calculates the previous day for the
    #           'DateT' object and returns the result. The calculation is
    #           done by the 'add_days(self, n)' function, where 'n' is
    #           -1. The result is returned to the caller; which is this function.
    #  @return A 'DateT' object with one day subtracted from the current object is returned
    def prev(self):
        return self.add_days(-1)

    ## @brief Calculates if the current 'DateT' object is before another 'DateT' object
    #  @details This function compares the current 'DateT' object with the first argument,
    #           which is also a 'DateT' object. If the current object is before the
    #           argument, then True is returned, otherwise, False. Also, if both 'DateT'
    #           objects are the same date, then the current object is assumed to be greater
    #           then the other object, and False is returned because it is not before it.
    #           Also, all calculations are done by the function __date_difference__. 
    #  @param d An abstract data of type 'DateT'.
    #  @return Returns True if current object/date is before the argument,
    #          and False otherwise.
    def before(self, d):
        return True if self.__date_difference__(d, False) < 0 else False

    ## @brief Calculates if the current 'DateT' object is after another 'DateT' object
    #  @details This function compares the current 'DateT' object against the first
    #           argument, which is also a 'DateT' object. If the current 'DateT' object is
    #           after the argument, then True is returned, otherwise, False. Also, if
    #           both 'DateT' objects are the same day, then the current object is assumed
    #           to be after the other object, and True is returned. Also, all calculations
    #           are done by the function __date_difference__. 
    #  @param d An abstract data of type 'DateT'. 
    #  @return Returns True if the current object/date is after the argument, 
    #          and False otherwise. 
    def after(self, d):
        return False if self.__date_difference__(d, False) < 0 else True

    ## @brief Calculates if two 'DateT' objects are the same date. 
    #  @details This function checks to see if two 'DateT' objects are the same date.
    #           The first 'DateT' object is the current object. The second is the
    #           first argument. This individually compares the day, month, and year
    #           of both 'DateT' objects to see if they are equal. If they are equal, then
    #           it returns True, otherwise, if they are different, False. 
    #  @param d An abstract data of type 'DateT'.
    #  @return Returns True if argument is same as current object, otherwise, False.
    def equal(self, d):
        return ((self.day() == d.day()) and (self.month() == d.month())
                                        and (self.year() == d.year()))

    ## @brief This function adds and subtracts days or one day to the 'DateT' object
    #  @details This function adds and/or subtracts day(s) to the 'DateT' object. It
    #           does this by converting the 'DateT' object to a 'datetime' object, and
    #           then adding 'n' number of days to it using the 'timedelta' function
    #           found in the 'datetime' library. Then, it converts the 'datetime'
    #           object back into a 'DateT' object and returns it to the caller.
    #           On the off hand that an Integer isn't passed as an argument, but a
    #           Float, it will be rounded up or down appropriately, and then casted
    #           to an Integer, and finally passed to the function, where it can return
    #           a correct 'DateT' object to the original caller. If a String is passed,
    #           then it will try to convert it into a Float and then an Integer. If
    #           that too fails then a ValueError is thrown with a message letting the
    #           person know what's the issue. The value 0 is passed for 'n' and the
    #           original date is returned with no modifications. This is an assumption,
    #           that takes care of malformed input. The type checking is also an
    #           assumption because the correct type may not be passed. 
    #  @param n An integer that will add days to the 'DateT' object.
    #  @throws ValueError Throws if the argument is not an Int or a Float or a
    #             String that can be converted into the former two.
    #  @return Returns a 'DateT' object with 'n' days added to it or subtracted from it. 
    def add_days(self, n):
        if (type(n) == int): # Checks if argument is an int
            datetime_with_days = date(self.y, self.m, self.d) + timedelta(days=n)
            date_with_days = DateT(datetime_with_days.day,
                                   datetime_with_days.month,
                                   datetime_with_days.year)
            return date_with_days
        elif (type(n) == float): # Checks if argument is a float
            #print("\nThe number '" + str(n) +
            #      "' is not an Integer.\nIt will be automatically converted to one.") # Temporarily Removed For Test Cases
            n = int(round(n))
            #print("The new number is: " + str(n) + "\n") # Temporarily Removed For Test Cases
            return self.add_days(n)
        else: # If argument is anything but an int or float
            try:
                n = float(n) # Tries to convert string to a float
                return self.add_days(n) 
            except ValueError: # Throws error if argument is malformed
                print("Not A Float Or Integer. Please Try Again")
                return self.add_days(0)

    ## @brief Calculates the difference between two days; supplied and current
    #  @details The function calculates the difference between two days; the current
    #           object and the argument. The difference is always a positive integer
    #           regardless of the dates. This is an assumption I am making because a
    #           difference of negative dates does not make much sense, especially because
    #           the inner workings of this function are hidden from the user. Also, the
    #           calculation is done by the function __date_difference__. 
    #  @param d An abstract data type of 'DateT'
    #  @return Returns a positive integer that is the number of days between two dates
    def days_between(self, d):
        return self.__date_difference__(d, True)

    ## @brief Calculates the difference between two days. 
    #  @details This function calculates the difference between two 'DateT' objects. It
    #           does this by converting both objects into 'DateTime' objects, subtracting
    #           the current object from the other object, and returning the difference.
    #           But, before it does this, it checks the types of the arguments. It first
    #           checks the type of the second argument. If it is a Boolean, the code will
    #           continue,and if it is not a Boolean, a TypeError will be raised. Side note:
    #           The type of the second argument does not need to be checked as it's value is
    #           always determined by the developer. However, a check has been added because
    #           this program was/is designed for change and maintainability. Then the
    #           type of the first argument is checked. If it is a 'datetime.datetime'
    #           object and has time associated with it, then it gets converted into a
    #           'datetime.date' object. Then, the current object gets converted into a
    #           'datetime.date' object. Then, the type of the first argument is checked
    #           to see if it is a 'DateT' object. If true, then it is converted into a
    #           'datetime.date' object and subtracted from the current object. Else, if the
    #           type of the first argument is a 'datetime.date', then it is subtracted
    #           from the current object. Else, if the type of the first argument is not
    #           'DateT' or 'datetime.date', then a TypeError is raised. Finally, if the
    #           second argument is True, the difference between the dates is returned as
    #           an absolute value. Else, it is returned as is. 
    #  @param d An abstract data type called 'DateT'.
    #  @param b A boolean value that indicates True or False.
    #  @throws TypeError Throws if second argument is not a Boolean
    #  @throws TypeError Throws if first argument is not a 'DateT' or
    #             'datetime.date' or 'datetime.datetime' object.
    #  @return Returns the difference between two 'DateT' objects.
    def __date_difference__(self, d, b):

        if (type(b) != bool): # Checks second argument and makes sure it is a Bool
            raise TypeError("Not A Boolean Value")

        if (type(d) == datetime):
            d = d.date() # Strips the time from the 'datetime' object

        # Converts the current object into a 'datetime' object, from a 'DateT' object
        current_object_datetime = datetime(self.year(), self.month(), self.day()).date()

        if (type(d) == DateT): # Checks type of first argument
            # Converts it to a 'datetime' object
            convert_to_datetime = datetime(d.year(), d.month(), d.day()).date()
            # Subtracts both 'datetime' objects and stores difference
            diff = (current_object_datetime - convert_to_datetime)
        elif (type(d) == date): # If first argument is already a 'datetime' object
            diff = (current_object_datetime - d) # Then subtract dates and store difference
        else: # If first argument is not a 'DateT' or 'datetime' object, then raise TypeError
            raise TypeError("The Types For The Date(s) Are Incorrect")
        
        if (b):
            return abs(diff.days) # Return absolute value of difference
        else:
            return (diff.days) # Return difference, as is, untouched

'''
ROUGH CODE

def main():

    test = DateT(20, 1, 2020)
    test2 = DateT(20, 1, 2020)
    test3 = datetime(2020, 1, 18).date()

    print(test2.prev().day())
    print()
    print(test2.add_days(4).__print_date__())
    print()
    print(test.before(test3))

main()

ROUGH CODE
'''

'''
OLD CODE

    ## @brief This function calculates and returns one day later
    #         than the current object.
    #  @details This function takes no arguments other than the implicit one
    #           that is 'self', which is the 'DateT' object. It takes this and
    #           adds one day to it and returns the result. This is accomplished
    #           by converting the 'DateT' object into a 'datetime' object and
    #           then using the function 'timedelta', found in the 'datetime'
    #           library and adding one day to it. The result is converted back
    #           into a 'DateT' object and returned to caller.
    #  @return (d, m, y) DateT object with one day added to it.
    def next(self):
        one_up_datetime = date(self.y, self.m, self.d) + timedelta(days=1)
        one_up_date = DateT(one_up_datetime.day, one_up_datetime.month, one_up_datetime.year)
        return one_up_date

OLD CODE
'''
