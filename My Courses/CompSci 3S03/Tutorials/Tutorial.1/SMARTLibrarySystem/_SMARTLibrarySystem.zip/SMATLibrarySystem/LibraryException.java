package SMATLibrarySystem;

public class LibraryException extends RuntimeException {

	public LibraryException(String message) {
		super(message);
	}

}
