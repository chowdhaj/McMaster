import java.util.Iterator;

public class MarbleBag_Array{

    private int currentIndex;

    private Marble[] marbles;

    public MarbleBag_Array()
    {
        System.out.println("Initialize Marble Bag...");
        marbles=new Marble[100];
        currentIndex=0;
    }

    public boolean add(String marble_name)
    {
        if(currentIndex==100)
        {
            System.out.println("Marble Bag is full!");
            return false;
        }
        for (int i=0;i<currentIndex;i++)
        {
            if(marbles[i].getMarble_name().equals(marble_name)) {
                System.out.println(marble_name + " already exists in the bag");
                return false;
            }
        }
        marbles[currentIndex]= new Marble(marble_name);
        currentIndex++;
        System.out.println(marble_name + " Has been successfully added to the Bag");
        return true;
    }

    public boolean del(String marble_name)
    {
        int index=0;
        for (index=0;index<currentIndex;index++)
        {
            if(marbles[index].getMarble_name().equals(marble_name)) {
                break;
            }
        }
        if(index<currentIndex)
        {
            for (int i=index;i<currentIndex-1;i++)
            {
                marbles[i]=marbles[i+1];
            }
            currentIndex--;
            System.out.println(marble_name + " is removed from the bag");
            return true;
        }
        else
        {
            System.out.println(marble_name + " doesn't exist in the bag");
            return false;
        }
    }

    public boolean delC(Marble.Colour colour)
    {
        int index=0;
        for (index=0;index<currentIndex;index++)
        {
            if(marbles[index].getColour().equals(colour)) {
                break;
            }
        }
        if(index<currentIndex)
        {
            for (int i=index;i<currentIndex-1;i++)
            {
                marbles[i]=marbles[i+1];
            }
            currentIndex--;
            System.out.println("A marble with the colour: " + colour + " has been removed from the bag.");
            return true;
        }
        else
        {
            System.out.println("There exist no marble with the colour: " + colour);
            return false;
        }
    }

    public boolean isEmpty() {
        return currentIndex==0;
    }

    public boolean isEmptyC(Marble.Colour colour) {
        for (int i=0;i<currentIndex;i++)
            if(marbles[i].getColour().equals(colour))
                return false;
        return true;
    }

    public int sizeC(Marble.Colour colour) {
        int count=0;
        for (int i=0;i<currentIndex;i++)
            if(marbles[i].getColour().equals(colour))
                count++;
        return count;
    }

    public int maxW() {
        int max=-1;
        for (int i=0;i<currentIndex;i++)
            max = Integer.max(max, marbles[i].getWeight());
        return max;
    }

    public int minW() {
        int min=Integer.MAX_VALUE;
        for (int i=0;i<currentIndex;i++)
            min = Integer.min(min, marbles[i].getWeight());

        if(min==Integer.MAX_VALUE)
            return -1;
        else
            return min;
    }

    public int size()
    {
        return currentIndex;
    }
}


