public class Q13_ExponentialFunction {


    static int power(int x, int y)
    {
        int temp;
        if( y == 0)
            return 1;
        temp = power(x, y/2);

        if (y%2 == 0)
            return temp*temp;
        else
        {
            if(y > 0)
                return x * temp * temp;
            else
                return (temp * temp) / x;
        }
    }

    public static void main(String[] args)
    {
        int n = 2;
		int f=power(n, n);
        System.out.println(power(f, f));
    }

}
