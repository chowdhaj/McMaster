public class Q8_DoubleList<Item> {

    private DoubleNode first;
    private DoubleNode last;
    private class DoubleNode
    {
        Item item;
        DoubleNode next;
        DoubleNode prev;
    }
    public Q8_DoubleList()
    {
        first = null;
        last = null;
    }
    public boolean isEmpty()
    {
        return first == null;
    }
    public void insertFront(Item i)
    {
        DoubleNode n = new DoubleNode();
        n.item = i;
        if(this.isEmpty())
        {
            this.first = n;
            this.last = n;
        }
        else
        {
            n.next = this.first;
            this.first.prev = n;
            this.first = n;
        }
    }
    public void insertEnd(Item i)
    {
        DoubleNode n = new DoubleNode();
        n.item = i;
        if(this.isEmpty())
        {
            this.first = n;
            this.last = n;
        }
        else
        {
            n.prev = this.last;
            this.last.next = n;
            this.last = n;
        }
    }
    public void removeFront()
    {
        this.first = this.first.next;
        this.first.prev = null;
    }
    public void removeEnd()
    {
        this.last = this.last.prev;
        this.last.next = null;
    }
    public void insertBefore(Item i, DoubleNode n)
    {
        DoubleNode d = new DoubleNode();
        d.item = i;
        d.next = n;
        n.prev.next = d;
        d.prev = n.prev;
        n.prev = d;
    }
    public void insertAfter(Item i, DoubleNode n)
    {
        DoubleNode d = new DoubleNode();
        d.item = i;
        d.prev = n;
        n.next.prev = d;
        d.next = n.next;
        n.next = d;
    }
    public void removeNode(DoubleNode n)
    {
        n.prev.next = n.next;
        n.next.prev = n.prev;
        n.next = null;
        n.prev = null;
    }
}
