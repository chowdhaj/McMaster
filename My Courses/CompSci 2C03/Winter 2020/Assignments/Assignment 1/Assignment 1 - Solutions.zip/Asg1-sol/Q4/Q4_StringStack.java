import java.util.Iterator;


public class Q4_StringStack implements Iterable<String> {

    private Node first;
    private class Node
    {
        String item;
        Node next;
    }
    private class StackIterator implements Iterator<String>
    {
        private Node curr;
        public StackIterator()
        {
            this.curr = first;
        }
        public String next()
        {
            String item = this.curr.item;
            this.curr = this.curr.next;
            return item;
        }
        public boolean hasNext()
        {
            return this.curr != null;
        }
        public void remove()
        {
            //We specify a return here to indicate that an empty remove() is intentional
            return;
        }
    }

    public Q4_StringStack()
    {
        this.first = null;
    }
    public void push(String s)
    {
        Node n = new Node();
        n.item = s;
        n.next = this.first;
        this.first = n;
    }
    public String pop()
    {
        String item = this.first.item;
        if(!this.isEmpty())
        {
            this.first = this.first.next;
        }
        return item;
    }
    public boolean isEmpty()
    {
        return this.first == null;
    }
    public static Q4_StringStack copy(Q4_StringStack s)
    {
        if(s.isEmpty())
        {
            return new Q4_StringStack();
        }
        else
        {
            Q4_StringStack copy = new Q4_StringStack();
            for(String str : s)
            {
                copy.push(str);
            }
            return Q4_StringStack.inverse(copy);
        }
    }
    public static Q4_StringStack inverse(Q4_StringStack s)
    {
        if(s.isEmpty())
        {
            return new Q4_StringStack();
        }
        else
        {
            Q4_StringStack inverse = new Q4_StringStack();
            for(String str : s)
            {
                inverse.push(str);
            }
            return inverse;
        }
    }
    public Iterator<String> iterator()
    {
        return new StackIterator();
    }


}
