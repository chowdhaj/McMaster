import java.util.EmptyStackException;
import java.util.Scanner;
import java.util.Stack;

public class Q3_Stack_Parentheses {

    public static void main(String[] args)
    {
        String input = new Scanner(System.in).nextLine();
        System.out.println(balanced(input));
    }
    public static boolean balanced(String input)
    {
        Stack<Character> stack = new Stack<Character>();
        try
        {
            for(char c : input.toCharArray())
            {
                switch(c)
                {
                    case ']':
                        if(stack.pop() != '[')
                            return false;
                        break;
                    case ')':
                        if(stack.pop() != '(')
                            return false;
                        break;
                    case '}':
                        if(stack.pop() != '{')
                            return false;
                        break;
                    default:
                        stack.push(c);
                }
            }
            return true;
        }
        catch(EmptyStackException e)
        {
            //This occurs if there are more right brackets than left ones.
            //The String is then unbalanced. Return false.
            return false;
        }
    }


}
