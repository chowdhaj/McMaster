public class Main_pointerMarble {

    public static void main(String[] args) {

        MarbleBag_Pointer bag=new MarbleBag_Pointer();

        bag.add("marble1");

        bag.add("marble2");

        bag.add("marble1");

        bag.del("marble2");

        bag.add("marble3");

        bag.add("marble4");

        System.out.println("Black Marbles count: " + bag.sizeC(Marble.Colour.BLACK));

        bag.delC(Marble.Colour.BLACK);

        System.out.println("BLUE Marbles count: " + bag.sizeC(Marble.Colour.BLUE));

        bag.delC(Marble.Colour.BLUE);

        System.out.println("PINK Marbles count: " + bag.sizeC(Marble.Colour.PINK));

        bag.delC(Marble.Colour.PINK);

        System.out.println("RED Marbles count: " + bag.sizeC(Marble.Colour.RED));

        bag.delC(Marble.Colour.RED);

        System.out.println("WHITE Marbles count: " + bag.sizeC(Marble.Colour.WHITE));

        bag.delC(Marble.Colour.WHITE);

    }
}
