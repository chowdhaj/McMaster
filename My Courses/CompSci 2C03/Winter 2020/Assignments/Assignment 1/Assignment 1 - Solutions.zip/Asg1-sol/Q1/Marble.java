import java.util.Random;

public class Marble {

    private String marble_name;
    private Colour colour;
    private int weight;

    public Marble(String marble_name)
    {
        this.marble_name=marble_name;

        //Randomly assign a colour from the set of colours

        int x = new Random().nextInt(Colour.values().length);
        this.colour = Colour.values()[x];

        //Randomly assign a weight from 1 to 100

        this.weight=new Random().nextInt(100) +1 ;
    }

    public Marble(String marble_name, Colour colour, int weight)
    {
        this.marble_name=marble_name;
        this.colour = colour;
        this.weight=weight;
    }

    public void setColour(Colour colour) {
        this.colour = colour;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public Colour getColour() {
        return colour;
    }

    public int getWeight() {
        return weight;
    }

    public String getMarble_name() {
        return marble_name;
    }

    enum Colour
    {
        WHITE, BLACK, PINK, RED, BLUE;
    }

}
