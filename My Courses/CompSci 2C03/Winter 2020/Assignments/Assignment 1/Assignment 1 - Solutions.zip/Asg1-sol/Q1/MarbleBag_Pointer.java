import java.util.Iterator;
import java.util.ListIterator;
import java.util.Random;

public class MarbleBag_Pointer implements Iterable{

    private Node first;
    private int size;

    public MarbleBag_Pointer()
    {
        System.out.println("Initialize Marble Bag...");
        size=0;
    }

    private class Node
    {
        Marble item;
        Node next;

    }

    public boolean add(String marble_name)
    {
        Iterator iter=this.iterator();
        while (iter.hasNext())
            if(((Node)iter.next()).item.getMarble_name().equals(marble_name)) {
                System.out.println(marble_name + " already exists in the bag");
                return false;
            }

        Node oldFirst=first;
        first=new Node();

        first.item= new Marble(marble_name);
        first.next=oldFirst;
        size++;
        System.out.println(marble_name + " Has been successfully added to the Bag");
        return true;
    }

    public boolean del(String marble_name)
    {
        Iterator iter=this.iterator();
        Node previous=null;
        while (iter.hasNext())
        {
            Node currentNode= (Node) iter.next();
            if(currentNode.item.getMarble_name().equals(marble_name))
            {
                if(previous==null) // First Node is to be removed
                {
                    first=first.next;
                }
                else
                {
                    previous.next = currentNode.next;
                }
                size--;
                System.out.println(marble_name + " is removed from the bag");
                return true;
            }
            previous=currentNode;
        }
        System.out.println(marble_name + " doesn't exist in the bag");
        return false;
    }

    public boolean delC(Marble.Colour colour)
    {
        Iterator iter=this.iterator();
        Node previous=null;
        while (iter.hasNext())
        {
            Node currentNode= (Node) iter.next();
            if(currentNode.item.getColour().equals(colour))
            {
                if(previous==null) // First Node is to be removed
                {
                    first=first.next;
                }
                else
                {
                    previous.next=currentNode.next;
                }
                size--;
                System.out.println("A marble with the colour: " + colour + " has been removed from the bag.");
                return true;
            }
            previous=currentNode;
        }
        System.out.println("There exist no marble with the colour: " + colour);
        return true;
    }

    public boolean isEmpty() {
        return first==null;
    }

    public boolean isEmptyC(Marble.Colour colour) {
        Iterator iter=this.iterator();
        while (iter.hasNext())
            if(((Node)iter.next()).item.getColour().equals(colour))
                return false;

        return true;
    }

    public int sizeC(Marble.Colour colour) {
        int count=0;
        Iterator iter=this.iterator();
        while (iter.hasNext())
            if(((Node)iter.next()).item.getColour().equals(colour))
                count++;
        return count;
    }

    public int maxW() {
        int max=-1;
        Iterator iter=this.iterator();
        while (iter.hasNext())
            max = Integer.max(max, ((Node)iter.next()).item.getWeight());
        return max;
    }

    public int minW() {
        int min=Integer.MAX_VALUE;
        Iterator iter=this.iterator();
        while (iter.hasNext())
            min = Integer.min(min, ((Node)iter.next()).item.getWeight());

        if(min==Integer.MAX_VALUE)
            return -1;
        else
            return min;
    }

    public int size()
    {
        return size;
    }


    @Override
    public Iterator iterator() {
        return new Iterator() {
            private Node current=first;

            @Override
            public boolean hasNext() {
                return current!=null;
            }

            @Override
            public Node next() {
                Node temp=current;
                current=current.next;
                return temp;
            }

        };
    }

}


