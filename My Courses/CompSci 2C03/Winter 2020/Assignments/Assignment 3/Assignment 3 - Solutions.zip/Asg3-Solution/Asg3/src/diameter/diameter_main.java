package diameter;

import infra.EdgeWeightedDigraph;

import java.io.File;

import Dijkstra.DijkstraSP;
import edu.princeton.cs.algs4.In;

public class diameter_main {
	public static void main(String[] args) {

		File myObj = new File("graph\\q10.txt");
		In in =new In(myObj);
		EdgeWeightedDigraph mydigraph=new EdgeWeightedDigraph(in);
		double diameter=0;
		for (int i = 0; i < mydigraph.V(); i++) {
			// no need to print the steps, that is why we set the last argument to be false
			DijkstraSP d=new DijkstraSP(mydigraph, i,null,false);
			if(d.maximumDistance()>diameter)
				diameter=d.maximumDistance();
		}
		
		System.out.println("Diameter is: " + diameter);
	}

}
