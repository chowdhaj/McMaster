package LZW;


public class LZW_main {

	public static void main(String[] args) {
		System.out.println("--------------Parta----------------");
		String a = "TOBEORNOTTOBE";
		LZW.compress(a);
		System.out.println("-------------------------------------");
		System.out.println("--------------Partb----------------");
		String b = "YABBADABBADABBADOO";
		LZW.compress(b);
		System.out.println("-------------------------------------");
		System.out.println("--------------Partc----------------");
		String c = "AAAAAAAAAAAAAAAAAAAAA";
		LZW.compress(c);
		System.out.println("-------------------------------------");

	}

}
