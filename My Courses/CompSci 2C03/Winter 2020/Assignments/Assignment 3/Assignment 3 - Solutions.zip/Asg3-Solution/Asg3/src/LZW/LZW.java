package LZW;

import java.util.HashMap;

public class LZW {

	public static void compress(String input) {
		HashMap<String, Integer> table = new HashMap<String, Integer>();
		int id = 0;
		for (int i = 0; i < input.length(); i++)
			table.put(String.valueOf(input.charAt(i)), id++);
		String P = "";
		for (int i = 0; i < input.length(); i++) {
			String C = String.valueOf(input.charAt(i));
			if (table.containsKey(P + C)) {
				P = P + C;
			} else {
				System.out.print(table.get(P) + "  ");
				table.put(P + C, id++);
				P = C;
			}
		}
		System.out.println("\nMap Table: ");
		for (String key : table.keySet()) {
			System.out.println(key + " -> " + table.get(key));
		}
	}
}
