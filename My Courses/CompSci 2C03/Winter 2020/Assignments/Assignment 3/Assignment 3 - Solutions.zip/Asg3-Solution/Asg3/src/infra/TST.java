package infra;

public class TST<Value> {
	private Node root; // root of trie

	private class Node {
		char c; // character
		Node left, mid, right; // left, middle, and right subtries
		Value val; // value associated with string
	}

	public Value get(String key) {
		Node x = get(root, key, 0);
		if (x == null)
			return null;
		return (Value) x.val;
	}

	private Node get(Node x, String key, int d) {
		if (x == null)
			return null;
		char c = key.charAt(d);
		if (c < x.c)
			return get(x.left, key, d);
		else if (c > x.c)
			return get(x.right, key, d);
		else if (d < key.length() - 1)
			return get(x.mid, key, d + 1);
		else
			return x;
	}

	public void put(String key, Value val) {
		root = put(root, key, val, 0);
	}

	private Node put(Node x, String key, Value val, int d) {
		char c = key.charAt(d);
		if (x == null) {
			x = new Node();
			x.c = c;
		}
		if (c < x.c)
			x.left = put(x.left, key, val, d);
		else if (c > x.c)
			x.right = put(x.right, key, val, d);
		else if (d < key.length() - 1)
			x.mid = put(x.mid, key, val, d + 1);
		else
			x.val = val;
		return x;
	}

	public String longestPrefixOf(String query) {
		if (query == null) {
			throw new IllegalArgumentException("Query cannot be null");
		}
		int length = search(root, query, 0, 0);
		return query.substring(0, length);
	}

	private int search(Node node, String query, int digit, int length) {
		if (node == null) {
			return length;
		}
		if (node.val != null) {
			length = digit + 1;
		}
		char nextChar = query.charAt(digit);
		if (nextChar < node.c) {
			return search(node.left, query, digit, length);
		} else if (nextChar > node.c) {
			return search(node.right, query, digit, length);
		} else if (digit < query.length() - 1) {
			return search(node.mid, query, digit + 1, length);
		} else {
			return length;
		}
	}
}
