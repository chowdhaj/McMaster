package Dijkstra;
import infra.EdgeWeightedDigraph;

import java.io.File;
import java.util.HashMap;

import edu.princeton.cs.algs4.In;


public class dijkstra_main {

	public static void main(String[] args) {
		HashMap<Integer, String> dictionary=new HashMap<Integer, String>();
		dictionary.put(0, "a");
		dictionary.put(1, "b");
		dictionary.put(2, "c");
		dictionary.put(3, "d");
		dictionary.put(4, "e");
		dictionary.put(5, "f");
		dictionary.put(6, "h");
		dictionary.put(7, "i");
		dictionary.put(8, "j");
		dictionary.put(9, "k");
		dictionary.put(10, "l");
		
		File myObj = new File("graph\\q10.txt");
		In in =new In(myObj);
		EdgeWeightedDigraph mydigraph=new EdgeWeightedDigraph(in);
		// The last argument is true to print the steps.
		// The dictionary is to map node ids to letters from the assignment 3, 
		// This dictionary is not part of the original implementation of the algorithm and is hard coded
		// You can change it to read from the same file if you like.
		DijkstraSP d=new DijkstraSP(mydigraph, 0,dictionary,true);
		System.out.println(d.printAllPath());
	}

}
