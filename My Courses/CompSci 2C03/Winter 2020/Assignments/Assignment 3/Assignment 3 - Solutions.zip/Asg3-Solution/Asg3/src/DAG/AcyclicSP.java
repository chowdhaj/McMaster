package DAG;

import infra.DirectedEdge;
import infra.EdgeWeightedDigraph;

import java.util.ArrayList;
import java.util.HashMap;

public class AcyclicSP {
	private DirectedEdge[] edgeTo;
	private double[] distTo;
	private int step=0;
	private int source;
	private HashMap<Integer, String> dictionary;

	public AcyclicSP(EdgeWeightedDigraph G, int s, ArrayList<Integer> topological, HashMap<Integer, String> dictionary) {
		this.dictionary=dictionary;
		this.source=s;
		edgeTo = new DirectedEdge[G.V()];
		distTo = new double[G.V()];
		for (int v = 0; v < G.V(); v++)
			distTo[v] = Double.POSITIVE_INFINITY;
		distTo[s] = 0.0;
		for (int v : topological)
		{
			for (DirectedEdge e : G.adj(v))
				relax(e);
			printStep();
		}
	}
	
	private void relax(DirectedEdge e) {
		int v = e.from(), w = e.to();
		if (distTo[w] > distTo[v] + e.weight()) {
			distTo[w] = distTo[v] + e.weight();
			edgeTo[w] = e;
		}
	}
	
	private void printStep()
	{
		System.out.println("Step: " + ++step + "\n");
		for (int i = 0; i < distTo.length; i++) 
			if(i!=source)
				System.out.print("[" + dictionary.get(source) + "->" + dictionary.get(i) + "=" + distTo[i] + "]");
		System.out.println("\n-------------------------------------------------");
	}
}