package BellmanFord;

import infra.EdgeWeightedDigraph;

import java.io.File;
import java.util.HashMap;

import edu.princeton.cs.algs4.In;

public class bellmanFord_main {

	public static void main(String[] args) {
		HashMap<Integer, String> dictionary=new HashMap<Integer, String>();
		dictionary.put(0, "s");
		dictionary.put(1, "t");
		dictionary.put(2, "x");
		dictionary.put(3, "y");
		dictionary.put(4, "z");
		
		File myObj = new File("graph\\q11.txt");
		In in =new In(myObj);
		EdgeWeightedDigraph mydigraph=new EdgeWeightedDigraph(in);
		BellmanFordSP bellmanford=new BellmanFordSP(mydigraph, 0,dictionary);
		System.out.println(bellmanford.printAllPath());
	
	}
	
		
}
