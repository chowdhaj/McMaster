package DAG;

import infra.EdgeWeightedDigraph;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import edu.princeton.cs.algs4.In;

public class dag_main {

	public static void main(String[] args) {
		HashMap<Integer, String> dictionary=new HashMap<Integer, String>();
		dictionary.put(0, "r");
		dictionary.put(1, "s");
		dictionary.put(2, "t");
		dictionary.put(3, "x");
		dictionary.put(4, "y");
		dictionary.put(5, "z");
		
		File myObj = new File("graph\\q13.txt");
		In in =new In(myObj);
		EdgeWeightedDigraph mydigraph=new EdgeWeightedDigraph(in);
		// The dictionary is to map node ids to letters from the assignment 3, 
		// This dictionary is not part of the original implementation of the algorithm and is hard coded
		// You can change it to read from the same file if you like.
		// The topology is the topological sort that is provided in the question (hard coded here)
		ArrayList<Integer> topology=new ArrayList<Integer>();
		topology.add(0);
		topology.add(1);
		topology.add(2);
		topology.add(3);
		topology.add(4);
		topology.add(5);
		AcyclicSP a=new AcyclicSP(mydigraph, 0,topology,dictionary);

	}

}
