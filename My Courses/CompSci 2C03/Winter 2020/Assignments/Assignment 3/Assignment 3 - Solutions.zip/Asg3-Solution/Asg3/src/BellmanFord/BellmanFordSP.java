package BellmanFord;
import java.util.HashMap;
import java.util.Stack;

import infra.DirectedEdge;
import infra.EdgeWeightedDigraph;
import edu.princeton.cs.algs4.Queue;

public class BellmanFordSP {
	private double[] distTo; // length of path to v
	private DirectedEdge[] edgeTo; // last edge on path to v
	private boolean[] onQ; // Is this vertex on the queue?
	private Queue<Integer> queue; // vertices being relaxed
	private int cost; // number of calls to relax()
	private Iterable<DirectedEdge> cycle; // negative cycle in edgeTo[]?
	private EdgeWeightedDigraph G;
	private HashMap<Integer, String> dictionary;
	private int step=0;
	private int source;

	public BellmanFordSP(EdgeWeightedDigraph G, int s, HashMap<Integer, String> dictionary) {
		this.dictionary=dictionary;
		this.source=s;
		this.G = G;
		distTo = new double[G.V()];
		edgeTo = new DirectedEdge[G.V()];
		onQ = new boolean[G.V()];
		queue = new Queue<Integer>();
		for (int v = 0; v < G.V(); v++)
			distTo[v] = Double.POSITIVE_INFINITY;
		distTo[s] = 0.0;
		queue.enqueue(s);
		onQ[s] = true;
		while (!queue.isEmpty() && !this.hasNegativeCycle()) {
			int v = queue.dequeue();
			onQ[v] = false;
			relax(v);
			printStep();
		}
		if(this.hasNegativeCycle())
			System.out.println("Cycle found!");
	}
	
	private void printStep()
	{
		System.out.println("Step: " + ++step + "\n");
		for (int i = 0; i < distTo.length; i++) 
			if(i!=source)
				System.out.print("[" + dictionary.get(source) + "->" + dictionary.get(i) + "=" + distTo[i] + "]");
		System.out.println("\n-------------------------------------------------");
	}

	private void relax(int v) {
		for (DirectedEdge e : G.adj(v)) {
			int w = e.to();
			if (distTo[w] > distTo[v] + e.weight()) {
				distTo[w] = distTo[v] + e.weight();
				edgeTo[w] = e;
				if (!onQ[w]) {
					queue.enqueue(w);
					onQ[w] = true;
				}
			}
			if (cost++ % G.V() == 0)
				findNegativeCycle();
		}
	}

	private void findNegativeCycle() {
		int V = edgeTo.length;
		EdgeWeightedDigraph spt;
		spt = new EdgeWeightedDigraph(V);
		for (int v = 0; v < V; v++)
			if (edgeTo[v] != null)
				spt.addEdge(edgeTo[v]);
		EdgeWeightedDirectedCycle cf;
		cf = new EdgeWeightedDirectedCycle(spt);
		cycle = cf.cycle();
	}

	public boolean hasNegativeCycle() {
		return cycle != null;
	}

	public Iterable<DirectedEdge> negativeCycle() {
		return cycle;
	}
	
	public String printAllPath()
	{
		StringBuilder sb=new StringBuilder();
		for(int i=0;i<G.V();i++)
		{
			Stack<Integer> path=pathTo(i, source);
			if(path!=null)
			{
				sb.append("Path from " + dictionary.get(source) + " to " + dictionary.get(i) + ": ");
				while (!path.isEmpty()) {
					sb.append(dictionary.get(path.pop()));
					if(!path.isEmpty())
						sb.append(" -> ");
				}
				sb.append("\n");
			}
		}
		return sb.toString();
	}
	
	private Stack<Integer> pathTo(int v, int s)
	 {
		if(v==s)
			return null;
		Stack<Integer> path = new Stack<Integer>();
		for (int x = v; x != s; x = edgeTo[x].from())
			path.push(x);
		path.push(s);
		return path;
	 } 

}