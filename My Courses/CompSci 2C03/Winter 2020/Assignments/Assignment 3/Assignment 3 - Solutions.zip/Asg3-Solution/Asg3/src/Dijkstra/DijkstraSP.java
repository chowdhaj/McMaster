package Dijkstra;
import infra.DirectedEdge;
import infra.EdgeWeightedDigraph;
import infra.IndexMinPQ;

import java.util.HashMap;
import java.util.Stack;

public class DijkstraSP {
	private DirectedEdge[] edgeTo;
	private double[] distTo;
	private IndexMinPQ<Double> pq;
	private EdgeWeightedDigraph graph;
	private int source;
	private int step=0;
	private HashMap<Integer, String> dictionary;
	public DijkstraSP(EdgeWeightedDigraph G, int s, HashMap<Integer, String> dictionary, boolean printSteps) {
		this.dictionary=dictionary;
		graph=G;
		source=s;
		edgeTo = new DirectedEdge[G.V()];
		distTo = new double[G.V()];
		pq = new IndexMinPQ<Double>(G.V());
		for (int v = 0; v < G.V(); v++)
			distTo[v] = Double.POSITIVE_INFINITY;
		distTo[s] = 0.0;
		//System.out.println("Inserting: " + s + "0");
		pq.insert(s, 0.0);
		while (!pq.isEmpty()) {
			int v = pq.deleteMin();
			//System.out.println("Delete Min: " + v );
			for (DirectedEdge e : G.adj(v))
				relax(e);
			if(printSteps)
				printStep();
		}
	}
	
	public double maximumDistance()
	{
		double max=0;
		for (int i = 0; i < distTo.length; i++) {
			if(distTo[i]>max)
				max=distTo[i];
		}
		return max;
	}
	
	private void printStep()
	{
		System.out.println("Step: " + ++step + "\n");
		for (int i = 0; i < distTo.length; i++) 
			if(i!=source)
				System.out.print("[" + dictionary.get(source) + "->" + dictionary.get(i) + "=" + distTo[i] + "]");
		System.out.println("\n-------------------------------------------------");
	}

	private void relax(DirectedEdge e) {
		int v = e.from(), w = e.to();
		if (distTo[w] > distTo[v] + e.weight()) {
			distTo[w] = distTo[v] + e.weight();
			edgeTo[w] = e;
			if (pq.contains(w))
			{
				//System.out.println("Decreasing: " + w + " : " + distTo[w]);
				pq.decreaseKey(w, distTo[w]);
			}
			else
			{
				//System.out.println("Inserting__: " + w + " : " + distTo[w]);
				pq.insert(w, distTo[w]);
				
			}
		}
	}
	
	public String printAllPath()
	{
		StringBuilder sb=new StringBuilder();
		for(int i=0;i<graph.V();i++)
		{
			Stack<Integer> path=pathTo(i, source);
			if(path!=null)
			{
				sb.append("Path from " + dictionary.get(source) + " to " + dictionary.get(i) + ": ");
				while (!path.isEmpty()) {
					sb.append(dictionary.get(path.pop()));
					if(!path.isEmpty())
						sb.append(" -> ");
				}
				sb.append("\n");
			}
		}
		return sb.toString();
	}
	
	
	private Stack<Integer> pathTo(int v, int s)
	 {
		if(v==s)
			return null;
		Stack<Integer> path = new Stack<Integer>();
		for (int x = v; x != s; x = edgeTo[x].from())
			path.push(x);
		path.push(s);
		return path;
	 } 
}
