package LSD;

public class LSD_main {
	
	public static void main(String []args)
	{
		String [] text=new String[16];
		text[0]="no";
		text[1]="is";
		text[2]="th";
		text[3]="ti";
		text[4]="fo";
		text[5]="al";
		text[6]="go";
		text[7]="pe";
		text[8]="to";
		text[9]="co";
		text[10]="to";
		text[11]="th";
		text[12]="ai";
		text[13]="of";
		text[14]="th";
		text[15]="pa";
		
		sort(text, 2);
	}
	
	private static void sort(String[] a, int W) { // Sort a[] on leading W
													// characters.
		int N = a.length;
		int R = 256;
		String[] aux = new String[N];
		int step=0;
		for (int d = W - 1; d >= 0; d--) { // Sort by key-indexed counting on
											// dth char.
			int[] count = new int[R + 1]; // Compute frequency counts.
			for (int i = 0; i < N; i++)
				count[a[i].charAt(d) + 1]++;
			for (int r = 0; r < R; r++)
				// Transform counts to indices.
				count[r + 1] += count[r];
			for (int i = 0; i < N; i++)
				// Distribute.
				aux[count[a[i].charAt(d)]++] = a[i];
			for (int i = 0; i < N; i++)
				// Copy back.
				a[i] = aux[i];
			// printing the resluts
			System.out.println("-------------------------------------------\nStep: " + ++step );
			for (int i = 0; i < N; i++)
				System.out.println(a[i]);
		}
	}
}
