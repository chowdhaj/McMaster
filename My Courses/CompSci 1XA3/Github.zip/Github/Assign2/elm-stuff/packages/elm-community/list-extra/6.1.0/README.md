# Convenience functions for working with List

[![Build Status](https://travis-ci.org/elm-community/list-extra.svg?branch=master)](https://travis-ci.org/elm-community/list-extra)

Experimental package with convenience functions for working with List.
Note that this API is experimental and likely to go through many more iterations.

Feedback and contributions are very welcome.
