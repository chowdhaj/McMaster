# Mess with the DOM

Sometimes you want to manually set the **focus** to a particular input field.

Other times you want to be able to control how things **scroll**.

This library makes it possible to do these kinds of operations as tasks.
