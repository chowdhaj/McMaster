***
# ^^^ My DOPE Resume/CV & ELM APP ^^^
***

## [1] Resume/CV
It is simple, elegant, yet powerful and effective. It gets the point across without being to wordy, and does so in an efficient manner. Resumes should be simple and concise. 

Special Thanks To The Following People:
* Joe Bloggs --> For His [Styling Sheet](http://www.bloggs.com/ "Joe's Website"). It’s simple yet effective.
* Google     --> For Providing Countless Examples Of Resumes/CVs

## [2] Elm App
My app is a colorful calculator. The buttons, fields, etc. are all different colors, making it pretty. But don't be fooled by its dazzling appearance, because its powerful and performs additional functions; well beyond the basic calculator on your laptop. I made this calculator to help me with my math homework and calculate the price of things I'm never going to buy. In the future, it'll solve things like formulas. 

Special Thanks To:
* **God Curtis D'Alves**: Thank you for helping me with the scaling issue.
* Pleb Charles: Thanks for making me aware of the scaling issue.
* [Tensor Programming](https://www.youtube.com/channel/UCYqCZOwHbnPwyjawKfE21wg/videos "His YouTube Channel"): For the styling sheet. 

***
