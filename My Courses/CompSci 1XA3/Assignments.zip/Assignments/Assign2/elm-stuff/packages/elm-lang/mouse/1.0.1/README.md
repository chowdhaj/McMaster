# Global Mouse Events

This library is useful for trickier mouse interactions. Things like:

  - Close a dialog when the user clicks outside of it.
  - Implement drag-and-drop for something.

So it is for more advanced use-cases. If you just want typical mouse events, everything you need should be in `elm-lang/html`.