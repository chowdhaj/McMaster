# Assignment 3 : Haskell Matlab

### Synopsis
This program is a simple math library, made in Haskell, that will assist you with your calculus homework. It can do a variety of things, such as:
1. Encode the following datatypes:
  * Addition
  * Subtraction
  * Multiplication
  * Cos, Sin, Log, Exp (natural)
  * Exponents
  * Variables
  * Constants
2. Evaluate an expression
3. Perform partial differentiation
4. Perform simplification of expressions
5. Parse strings into an expression datatype
  * You can read more about this in Haddock [documentation]

### How-To 
###### Honestly, Just Read The Documentation/Comments [I'm To Lazy To Finish This]
Coming ~~Soon~~ Never 

### References
1. Curtis D'Alves  : Ideas, Code, & Help
2. Allen Chen      : Help With ExprEval.hs
3. Noa Barsky      : Help With ExprDiff.hs
4. Google          : Resource Haven
5. Wikipedia       : Math Help

### License
This software is protected under WTFPL. Do whatever you want, but don't come crying to me if you mess up. 

---

`Cheers!`
