#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

volatile sig_atomic_t alarm_received = 0;

void my_handler(int signo) {
  printf("caught signal SIGALRM\n");
  alarm_received = 1;
  return;
}

int main() {

  struct sigaction saa;
  saa.sa_handler = my_handler;
  sigfillset(&saa.sa_mask);     // block all signals
  saa.sa_flags = 0;

  sigaction(SIGALRM,&saa,NULL);

  alarm(5);

  // the loop does not represent waiting for the signal
  // but doing something until interruped by SIGALRM
  for( ; ! alarm_received ; ) ;

  printf("done\n");
  return 0;
}

