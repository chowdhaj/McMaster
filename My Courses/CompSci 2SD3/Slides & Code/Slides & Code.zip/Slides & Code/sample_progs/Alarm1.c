#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

int main() {

  alarm(5);
  for( ; ; ) ;
  printf("done\n");
  return 0;
}
