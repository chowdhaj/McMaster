/* program 12.2 */

#include <stdio.h>
#include "restart.h"

#define BUFSIZE 1024

void *processfd(void *arg) { /* process commands read from file descriptor */
  char buf[BUFSIZE];
  int fd;
  ssize_t nbytes;

  fd = *((int *)(arg));
  printf("thread %ld starts\n",pthread_self());
  while (1) {
    if ((nbytes = readline(fd, buf, BUFSIZE)) <= 0)
      break;
  }
  printf("thread %ld terminates\n",pthread_self());
  return NULL;
}
